from cfsil4py.cfsil4py_mod import muiCouplingIQNILS
